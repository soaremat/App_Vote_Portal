import { User } from 'lucide-react';
import { Chapa } from '../../App';

interface ParticipantesEleicaoScreenProps {
  onBack: () => void;
  nomeEleicao: string;
  chapas: Chapa[];
}

export function ParticipantesEleicaoScreen({ onBack, nomeEleicao, chapas }: ParticipantesEleicaoScreenProps) {
  const participantes = chapas.filter(chapa => chapa.nomeEleicao === nomeEleicao);

  return (
    <div className="min-h-screen bg-[#002169] p-[10px]">
      <div className="min-h-screen bg-[#F6F6F6] rounded-[10px] overflow-hidden">
        <div className="bg-[#002B5C] p-6 flex items-center justify-center">
          <h1 style={{ fontFamily: 'Poppins, sans-serif' }}>
            <span className="text-white text-2xl md:text-3xl" style={{ fontWeight: 700 }}>Portal do </span>
            <span className="text-[#FF3333] text-2xl md:text-3xl" style={{ fontWeight: 700 }}>Voto</span>
          </h1>
        </div>

        <div className="p-6 md:p-8 max-w-2xl mx-auto min-h-[calc(100vh-80px)] flex flex-col">
          <h2 className="text-black mb-2 text-center" style={{ fontSize: '30px', fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}>
            Participantes
          </h2>
          <p className="text-gray-600 mb-6 text-center" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 600 }}>
            {nomeEleicao}
          </p>

          <div className="flex-1">
            {participantes.length === 0 ? (
              <div className="flex items-center justify-center min-h-[40vh]">
                <p className="text-gray-500 text-xl text-center" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 900 }}>Nenhum participante cadastrado</p>
              </div>
            ) : (
              <div className="space-y-4 mb-6">
                {participantes.map((chapa) => (
                  <div
                    key={chapa.id}
                    className="w-full bg-[#80A4F0] rounded-[20px] p-6"
                  >
                    <div className="flex items-center justify-between gap-6">
                      <div className="flex-1 space-y-1">
                        <p className="text-black" style={{ fontWeight: 400 }}>
                          <span style={{ fontWeight: 700 }}>Chapa:</span> {chapa.nomeChapa}
                        </p>
                        <p className="text-black" style={{ fontWeight: 400 }}>
                          <span style={{ fontWeight: 700 }}>Candidato:</span> {chapa.nomeCandidato}
                        </p>
                        <p className="text-black" style={{ fontWeight: 400 }}>
                          <span style={{ fontWeight: 700 }}>Vice:</span> {chapa.nomeVice}
                        </p>
                        <p className="text-black" style={{ fontWeight: 400 }}>
                          <span style={{ fontWeight: 700 }}>Número de voto:</span> {chapa.numero}
                        </p>
                      </div>

                      <div className="flex items-center justify-center">
                        {chapa.imagemUrl ? (
                          <img src={chapa.imagemUrl} alt={chapa.nomeCandidato} className="w-24 h-24 object-cover rounded-lg" />
                        ) : (
                          <div className="w-24 h-24 bg-white/30 rounded-lg flex items-center justify-center">
                            <User className="w-16 h-16 text-gray-600" />
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <button
            onClick={onBack}
            className="w-full text-black py-4 rounded-lg hover:bg-gray-200 transition-colors text-xl"
            style={{ fontWeight: 700, fontFamily: 'Poppins, sans-serif' }}
          >
            Voltar
          </button>
        </div>
      </div>
    </div>
  );
}