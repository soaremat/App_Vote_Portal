import { ArrowLeft, Trash2, Pencil } from 'lucide-react';
import { Eleicao } from '../../App';
import { useState } from 'react';

interface EleicoesAtivasScreenProps {
  onBack: () => void;
  onCriar: () => void;
  onEdit: (eleicao: Eleicao) => void;
  onDelete: (id: string) => void;
  onViewParticipantes: (nomeEleicao: string) => void;
  eleicoes: Eleicao[];
}

export function EleicoesAtivasScreen({ onBack, onCriar, onEdit, onDelete, onViewParticipantes, eleicoes }: EleicoesAtivasScreenProps) {
  const [eleicaoToDelete, setEleicaoToDelete] = useState<string | null>(null);

  const handleDelete = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    setEleicaoToDelete(id);
  };

  const confirmDelete = () => {
    if (eleicaoToDelete) {
      onDelete(eleicaoToDelete);
      setEleicaoToDelete(null);
    }
  };

  const cancelDelete = () => {
    setEleicaoToDelete(null);
  };

  const handleEdit = (e: React.MouseEvent, eleicao: Eleicao) => {
    e.stopPropagation();
    onEdit(eleicao);
  };

  return (
    <div className="min-h-screen bg-[#002169] p-[10px]">
      <div className="min-h-screen bg-[#F6F6F6] rounded-[10px] overflow-hidden">
        <div className="bg-[#002B5C] p-6 flex items-center justify-center">
          <h1 style={{ fontFamily: 'Poppins, sans-serif' }}>
            <span className="text-white text-2xl md:text-3xl" style={{ fontWeight: 700 }}>Portal do </span>
            <span className="text-[#FF3333] text-2xl md:text-3xl" style={{ fontWeight: 700 }}>Voto</span>
          </h1>
        </div>

        <div className="p-6 md:p-8 max-w-2xl mx-auto min-h-[calc(100vh-80px)] flex flex-col">
          <h2 className="text-black mb-6 text-center" style={{ fontSize: '30px', fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}>
            Eleições ativas
          </h2>

          <div className="flex-1">
            {eleicoes.length === 0 ? (
              <div className="flex items-center justify-center min-h-[40vh]">
                <p className="text-gray-500 text-xl text-center" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 900 }}>Nenhuma eleição criada</p>
              </div>
            ) : (
              <div className="space-y-4 mb-6">
                {eleicoes.map((eleicao) => (
                  <div
                    key={eleicao.id}
                    onClick={() => onViewParticipantes(eleicao.nome)}
                    className={`w-full ${eleicao.status === 'ativo' ? 'bg-[#A9FEAC]' : 'bg-[#FA8989]'} rounded-lg p-6 hover:opacity-90 transition-opacity relative cursor-pointer`}
                  >
                    <div className="space-y-2">
                      <div>
                        <p className="text-gray-700 text-sm mb-1">Nome da eleição</p>
                        <h3 className="text-black text-xl" style={{ fontWeight: 700 }}>{eleicao.nome}</h3>
                      </div>
                      
                      <div>
                        <p className="text-gray-700 text-sm mb-1">Data limite</p>
                        <p className="text-black">De: {eleicao.dataInicio} à {eleicao.dataFim}</p>
                      </div>
                      
                      <div>
                        <p className="text-gray-700 text-sm mb-1">Status</p>
                        <p className="text-black" style={{ fontWeight: 600 }}>
                          {eleicao.status === 'ativo' ? 'Ativo' : 'Encerrado'}
                        </p>
                      </div>
                    </div>
                    
                    <button
                      onClick={(e) => handleEdit(e, eleicao)}
                      className="absolute bottom-4 right-12 text-gray-700 hover:text-blue-600 transition-colors"
                    >
                      <Pencil className="w-5 h-5" />
                    </button>

                    <button
                      onClick={(e) => handleDelete(e, eleicao.id)}
                      className="absolute bottom-4 right-4 text-gray-700 hover:text-red-600 transition-colors"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="space-y-3">
            <button
              onClick={onCriar}
              className="w-full bg-[#4CAF50] text-white py-4 rounded-lg hover:bg-[#45A049] transition-colors text-xl"
              style={{ fontWeight: 700 }}
            >
              Criar eleição
            </button>

            <div className="pt-4">
              <button
                onClick={onBack}
                className="w-full text-black py-4 rounded-lg hover:bg-gray-200 transition-colors text-lg"
                style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}
              >
                Voltar
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Modal de Confirmação de Exclusão */}
      {eleicaoToDelete && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg p-8 max-w-md w-full shadow-xl">
            <h3 className="text-black text-xl mb-6 text-center" style={{ fontWeight: 700, fontFamily: 'Poppins, sans-serif' }}>
              Deseja mesmo excluir esta eleição?
            </h3>
            
            <div className="flex gap-4">
              <button
                onClick={cancelDelete}
                className="flex-1 bg-gray-300 text-black py-3 rounded-lg hover:bg-gray-400 transition-colors"
                style={{ fontWeight: 700, fontFamily: 'Poppins, sans-serif' }}
              >
                Cancelar
              </button>
              
              <button
                onClick={confirmDelete}
                className="flex-1 bg-[#FF3333] text-white py-3 rounded-lg hover:bg-[#E02020] transition-colors"
                style={{ fontWeight: 700, fontFamily: 'Poppins, sans-serif' }}
              >
                Excluir
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}