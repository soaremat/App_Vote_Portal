import { useState } from 'react';
import { ArrowLeft } from 'lucide-react';
import { Eleicao } from '../../App';

interface FormEleicaoScreenProps {
  onBack: () => void;
  onSave: (eleicao: Omit<Eleicao, 'id'>) => void;
  initialData?: Eleicao | null;
}

export function FormEleicaoScreen({ onBack, onSave, initialData }: FormEleicaoScreenProps) {
  const [nome, setNome] = useState(initialData?.nome || '');
  const [dataInicio, setDataInicio] = useState(initialData?.dataInicio || '');
  const [dataFim, setDataFim] = useState(initialData?.dataFim || '');
  const [horaFim, setHoraFim] = useState(initialData?.horaFim || '');
  const [status, setStatus] = useState<'ativo' | 'encerrado'>(initialData?.status || 'ativo');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (nome && dataInicio && dataFim && horaFim) {
      onSave({ nome, dataInicio, dataFim, horaFim, status });
    } else {
      alert('Preencha todos os campos');
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
    }
  };

  return (
    <div className="min-h-screen bg-[#002169] p-[10px]">
      <div className="min-h-screen bg-[#F6F6F6] rounded-[10px] overflow-hidden">
        <div className="bg-[#002B5C] p-6 flex items-center justify-center">
          <h1 style={{ fontFamily: 'Poppins, sans-serif' }}>
            <span className="text-white text-2xl md:text-3xl" style={{ fontWeight: 700 }}>Portal do </span>
            <span className="text-[#FF3333] text-2xl md:text-3xl" style={{ fontWeight: 700 }}>Voto</span>
          </h1>
        </div>

        <div className="p-6 md:p-8 max-w-2xl mx-auto min-h-[calc(100vh-80px)] flex flex-col">
          <h2 className="text-black mb-8 text-2xl md:text-3xl text-center" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}>
            {initialData ? 'Editar' : 'Criar'} eleição
          </h2>

          <form onSubmit={handleSubmit} className="flex-1 flex flex-col">
            <div className="flex-1 space-y-6">
              <div>
                <input
                  type="text"
                  placeholder="Nome da eleição"
                  value={nome}
                  onChange={(e) => setNome(e.target.value)}
                  onKeyDown={handleKeyDown}
                  className="w-full bg-transparent border-b border-gray-400 text-black placeholder-gray-500 py-3 px-0 focus:outline-none focus:border-black text-lg"
                  required
                />
              </div>

              <div>
                <p className="text-gray-700 mb-3">Data limite</p>
                <div className="flex items-center gap-4">
                  <div className="flex-1">
                    <label className="text-sm text-gray-600">De:</label>
                    <input
                      type="date"
                      value={dataInicio}
                      onChange={(e) => setDataInicio(e.target.value)}
                      onKeyDown={handleKeyDown}
                      className="w-full bg-transparent border-b border-gray-400 text-black py-3 px-0 focus:outline-none focus:border-black"
                      required
                    />
                  </div>
                  <span className="text-gray-500">à</span>
                  <div className="flex-1">
                    <label className="text-sm text-gray-600">Até:</label>
                    <input
                      type="date"
                      value={dataFim}
                      onChange={(e) => setDataFim(e.target.value)}
                      onKeyDown={handleKeyDown}
                      className="w-full bg-transparent border-b border-gray-400 text-black py-3 px-0 focus:outline-none focus:border-black"
                      required
                    />
                  </div>
                </div>
              </div>

              <div>
                <p className="text-gray-700 mb-3">Hora limite</p>
                <div className="flex items-center gap-4">
                  <div className="flex-1">
                    <label className="text-sm text-gray-600">Até:</label>
                    <input
                      type="time"
                      value={horaFim}
                      onChange={(e) => setHoraFim(e.target.value)}
                      onKeyDown={handleKeyDown}
                      className="w-full bg-transparent border-b border-gray-400 text-black py-3 px-0 focus:outline-none focus:border-black"
                      required
                    />
                  </div>
                </div>
              </div>

              {initialData && (
                <div>
                  <p className="text-gray-700 mb-2">Status</p>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as 'ativo' | 'encerrado')}
                    className="w-full bg-white border border-gray-400 text-black py-3 px-3 rounded-[20px] focus:outline-none focus:border-black text-lg"
                  >
                    <option value="ativo">Ativo</option>
                    <option value="encerrado">Encerrado</option>
                  </select>
                </div>
              )}

              <div className="space-y-3 mt-8">
                <button
                  type="submit"
                  className="w-full bg-[#4CAF50] text-white py-4 rounded-lg hover:bg-[#45A049] transition-colors text-xl"
                  style={{ fontWeight: 700, fontFamily: 'Poppins, sans-serif' }}
                >
                  {initialData ? 'Salvar' : 'Iniciar período'}
                </button>

                <button
                  type="button"
                  onClick={onBack}
                  className="w-full text-black py-4 rounded-lg hover:bg-gray-200 transition-colors text-lg"
                  style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}
                >
                  Voltar
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}