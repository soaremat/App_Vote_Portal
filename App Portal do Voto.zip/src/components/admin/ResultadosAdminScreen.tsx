import { Eleicao } from '../../App';

interface ResultadosAdminScreenProps {
  onBack: () => void;
  eleicoes: Eleicao[];
  onSelectEleicao: (eleicao: Eleicao) => void;
}

export function ResultadosAdminScreen({ onBack, eleicoes, onSelectEleicao }: ResultadosAdminScreenProps) {
  return (
    <div className="min-h-screen bg-[#002169] p-[10px]">
      <div className="min-h-screen bg-[#F6F6F6] rounded-[10px] overflow-hidden">
        <div className="bg-[#002B5C] p-6 flex items-center justify-center">
          <h1 style={{ fontFamily: 'Poppins, sans-serif' }}>
            <span className="text-white text-2xl md:text-3xl" style={{ fontWeight: 700 }}>Portal do </span>
            <span className="text-[#FF3333] text-2xl md:text-3xl" style={{ fontWeight: 700 }}>Voto</span>
          </h1>
        </div>

        <div className="p-6 md:p-8 max-w-4xl mx-auto min-h-[calc(100vh-80px)] flex flex-col">
          <h2 className="text-black mb-6 text-center" style={{ fontSize: '30px', fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}>
            Resultados parciais
          </h2>

          <div className="flex-1 overflow-y-auto space-y-4 mb-6">
            {eleicoes.length === 0 ? (
              <div className="flex items-center justify-center min-h-[40vh]">
                <p className="text-gray-500 text-xl text-center" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 900 }}>
                  Nenhuma eleição criada ainda
                </p>
              </div>
            ) : (
              eleicoes.map((eleicao) => (
                <div
                  key={eleicao.id}
                  onClick={() => onSelectEleicao(eleicao)}
                  className="bg-white rounded-lg p-6 shadow-md cursor-pointer hover:shadow-lg transition-shadow border-l-4 border-[#1976D2]"
                >
                  <h3 className="text-black text-xl mb-2" style={{ fontWeight: 700, fontFamily: 'Poppins, sans-serif' }}>
                    {eleicao.nome}
                  </h3>
                  <div className="flex items-center gap-4 text-gray-600">
                    <span className="text-sm">
                      Início: {eleicao.dataInicio}
                    </span>
                    <span className="text-sm">
                      Fim: {eleicao.dataFim} às {eleicao.horaFim}
                    </span>
                    <span
                      className={`ml-auto px-3 py-1 rounded-full text-sm ${
                        eleicao.status === 'ativo' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                      }`}
                      style={{ fontWeight: 600 }}
                    >
                      {eleicao.status === 'ativo' ? 'Ativa' : 'Encerrada'}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>

          <div className="pt-4">
            <button
              onClick={onBack}
              className="w-full bg-[#1976D2] text-white py-4 rounded-lg hover:bg-[#1565C0] transition-colors text-xl"
              style={{ fontWeight: 700, fontFamily: 'Poppins, sans-serif' }}
            >
              Voltar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}