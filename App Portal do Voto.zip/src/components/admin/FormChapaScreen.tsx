import { useState } from 'react';
import { ArrowLeft, Trash2, Upload } from 'lucide-react';
import { Chapa } from '../../App';

interface FormChapaScreenProps {
  onBack: () => void;
  onSave: (chapa: Omit<Chapa, 'id'>) => void;
  onDelete?: (id: string) => void;
  initialData?: Chapa | null;
  allChapas: Chapa[];
}

export function FormChapaScreen({ onBack, onSave, onDelete, initialData, allChapas }: FormChapaScreenProps) {
  const [nomeCandidato, setNomeCandidato] = useState(initialData?.nomeCandidato || '');
  const [nomeChapa, setNomeChapa] = useState(initialData?.nomeChapa || '');
  const [nomeVice, setNomeVice] = useState(initialData?.nomeVice || '');
  const [numero, setNumero] = useState(initialData?.numero || '');
  const [imagemUrl, setImagemUrl] = useState(initialData?.imagemUrl || '');
  const [nomeEleicao, setNomeEleicao] = useState(initialData?.nomeEleicao || '');
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (nomeCandidato && nomeChapa && nomeVice && numero.length === 2) {
      // Verificar se já existe um candidato com o mesmo número na mesma eleição
      const numeroDuplicado = allChapas.find(chapa => 
        chapa.numero === numero && 
        chapa.nomeEleicao?.toLowerCase() === nomeEleicao.toLowerCase() &&
        chapa.id !== initialData?.id // Excluir o próprio candidato ao editar
      );

      if (numeroDuplicado) {
        alert(`Já existe um candidato com o número ${numero} na eleição "${nomeEleicao}". Por favor, escolha outro número.`);
        return;
      }

      onSave({ nomeCandidato, nomeChapa, nomeVice, numero, imagemUrl, nomeEleicao });
    } else {
      alert('Preencha todos os campos corretamente');
    }
  };

  const handleNumeroChange = (value: string, position: number) => {
    if (value.length > 1) return;
    // Aceita apenas números
    if (value && !/^\d$/.test(value)) return;
    
    const numeroArray = numero.split('');
    numeroArray[position] = value;
    setNumero(numeroArray.join(''));
    
    // Move para o próximo campo automaticamente
    if (value && position === 0) {
      const nextInput = document.querySelector('[data-field="numero-1"]') as HTMLInputElement;
      if (nextInput) nextInput.focus();
    }
  };

  const handleDelete = () => {
    if (initialData && onDelete) {
      onDelete(initialData.id);
      setShowDeleteConfirm(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>, nextField?: string) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      if (nextField) {
        const nextElement = document.querySelector(`[data-field="${nextField}"]`) as HTMLInputElement;
        if (nextElement) {
          nextElement.focus();
        }
      }
    }
  };

  return (
    <div className="min-h-screen bg-[#002169] p-[10px]">
      <div className="min-h-screen bg-[#F6F6F6] rounded-[10px] overflow-hidden">
        <div className="bg-[#002B5C] p-6 flex items-center justify-center">
          <h1 style={{ fontFamily: 'Poppins, sans-serif' }}>
            <span className="text-white text-2xl md:text-3xl" style={{ fontWeight: 700 }}>Portal do </span>
            <span className="text-[#FF3333] text-2xl md:text-3xl" style={{ fontWeight: 700 }}>Voto</span>
          </h1>
        </div>

        <div className="p-6 md:p-8 max-w-2xl mx-auto min-h-[calc(100vh-80px)] flex flex-col">
          {initialData && onDelete && (
            <div className="flex justify-start mb-4">
              <button
                onClick={() => setShowDeleteConfirm(true)}
                className="text-red-600 hover:text-red-800 transition-colors"
                title="Excluir"
              >
                <Trash2 className="w-6 h-6" />
              </button>
            </div>
          )}
          
          <form onSubmit={handleSubmit} className="flex-1 flex flex-col">
            <div className="flex-1 space-y-6">
              <div className="flex gap-4">
                <div className="flex-1 flex items-end">
                  <input
                    type="text"
                    placeholder="Nome do candidato"
                    value={nomeCandidato}
                    onChange={(e) => setNomeCandidato(e.target.value)}
                    onKeyDown={(e) => handleKeyDown(e, 'nomeVice')}
                    data-field="nomeCandidato"
                    className="w-full bg-white border-b border-gray-400 text-black placeholder-gray-500 py-3 px-0 focus:outline-none focus:border-black"
                    required
                  />
                </div>
                
                <div className="w-48 h-48 bg-[#D3D3D3] rounded-lg flex flex-col items-center justify-center text-center p-3 relative overflow-hidden cursor-pointer hover:bg-[#C3C3C3] transition-colors flex-shrink-0">
                  {imagemUrl ? (
                    <img src={imagemUrl} alt="Preview" className="absolute inset-0 w-full h-full object-cover" />
                  ) : (
                    <p className="text-gray-600">adicionar foto do candidato</p>
                  )}
                  <input
                    type="text"
                    placeholder="URL da imagem"
                    value={imagemUrl}
                    onChange={(e) => setImagemUrl(e.target.value)}
                    onKeyDown={(e) => handleKeyDown(e)}
                    className="absolute inset-0 opacity-0 cursor-pointer"
                    title="Cole a URL da imagem aqui"
                  />
                </div>
              </div>

              <div>
                <input
                  type="text"
                  placeholder="Nome do vice"
                  value={nomeVice}
                  onChange={(e) => setNomeVice(e.target.value)}
                  onKeyDown={(e) => handleKeyDown(e, 'nomeChapa')}
                  data-field="nomeVice"
                  className="w-full bg-white border-b border-gray-400 text-black placeholder-gray-500 py-3 px-0 focus:outline-none focus:border-black"
                  required
                />
              </div>

              <div>
                <input
                  type="text"
                  placeholder="Nome da chapa"
                  value={nomeChapa}
                  onChange={(e) => setNomeChapa(e.target.value)}
                  onKeyDown={(e) => handleKeyDown(e, 'nomeEleicao')}
                  data-field="nomeChapa"
                  className="w-full bg-white border-b border-gray-400 text-black placeholder-gray-500 py-3 px-0 focus:outline-none focus:border-black"
                  required
                />
              </div>

              <div>
                <input
                  type="text"
                  placeholder="Nome da eleição"
                  value={nomeEleicao}
                  onChange={(e) => setNomeEleicao(e.target.value)}
                  onKeyDown={(e) => handleKeyDown(e, 'numero-0')}
                  data-field="nomeEleicao"
                  className="w-full bg-white border-b border-gray-400 text-black placeholder-gray-500 py-3 px-0 focus:outline-none focus:border-black"
                />
              </div>

              <div>
                <p className="text-black mb-3">Número do candidato:</p>
                <div className="flex gap-3 justify-center">
                  <input
                    type="text"
                    maxLength={1}
                    value={numero[0] || ''}
                    onChange={(e) => handleNumeroChange(e.target.value, 0)}
                    className="w-16 h-16 border-2 border-black text-black text-center text-2xl rounded-lg focus:outline-none focus:border-[#FFC107]"
                    style={{ fontWeight: 700, fontFamily: 'Poppins, sans-serif' }}
                    required
                    onKeyDown={(e) => handleKeyDown(e, 'numero-1')}
                    data-field="numero-0"
                  />
                  <input
                    type="text"
                    maxLength={1}
                    value={numero[1] || ''}
                    onChange={(e) => handleNumeroChange(e.target.value, 1)}
                    className="w-16 h-16 border-2 border-black text-black text-center text-2xl rounded-lg focus:outline-none focus:border-[#FFC107]"
                    style={{ fontWeight: 700, fontFamily: 'Poppins, sans-serif' }}
                    required
                    onKeyDown={(e) => handleKeyDown(e)}
                    data-field="numero-1"
                  />
                </div>
              </div>

              <div className="space-y-3 pt-6">
                <button
                  type="submit"
                  className="w-full bg-[#FFC107] text-white py-4 rounded-lg hover:bg-[#FFB300] transition-colors text-xl"
                  style={{ fontWeight: 700, fontFamily: 'Poppins, sans-serif' }}
                >
                  Salvar
                </button>

                <button
                  type="button"
                  onClick={onBack}
                  className="w-full text-black py-4 rounded-lg hover:bg-gray-200 transition-colors text-xl"
                  style={{ fontWeight: 700, fontFamily: 'Poppins, sans-serif' }}
                >
                  Cancelar
                </button>
              </div>
            </div>
          </form>
        </div>

        {showDeleteConfirm && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-[20px] p-8 max-w-md w-full">
              <h3 className="text-2xl mb-4 text-center" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}>
                Deseja mesmo apagar?
              </h3>
              <div className="flex gap-3">
                <button
                  onClick={() => setShowDeleteConfirm(false)}
                  className="flex-1 bg-gray-300 text-black py-3 rounded-lg hover:bg-gray-400 transition-colors"
                  style={{ fontWeight: 600 }}
                >
                  Cancelar
                </button>
                <button
                  onClick={handleDelete}
                  className="flex-1 bg-[#E74C3C] text-white py-3 rounded-lg hover:bg-[#C0392B] transition-colors"
                  style={{ fontWeight: 600 }}
                >
                  Apagar
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}