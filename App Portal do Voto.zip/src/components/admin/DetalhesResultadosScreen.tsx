import { User } from 'lucide-react';
import { Eleicao } from '../../App';

interface ResultWithChapa {
  id: string;
  nomeChapa: string;
  nomeCandidato: string;
  nomeVice: string;
  numero: string;
  imagemUrl?: string;
  votes: number;
  percentage: number;
}

interface DetalhesResultadosScreenProps {
  onBack: () => void;
  eleicao: Eleicao;
  results: ResultWithChapa[];
}

export function DetalhesResultadosScreen({ onBack, eleicao, results }: DetalhesResultadosScreenProps) {
  const totalVotos = results.reduce((sum, r) => sum + r.votes, 0);
  const isElectionActive = eleicao.status === 'ativo';
  const endMessage = isElectionActive 
    ? `Encerra em ${eleicao.dataFim} às ${eleicao.horaFim}`
    : `Votação encerrada em ${eleicao.dataFim} às ${eleicao.horaFim}`;

  return (
    <div className="min-h-screen bg-[#002169] p-[10px]">
      <div className="min-h-screen bg-[#F6F6F6] rounded-[10px] overflow-hidden">
        <div className="bg-[#002B5C] p-6 flex items-center justify-center">
          <h1 style={{ fontFamily: 'Poppins, sans-serif' }}>
            <span className="text-white text-2xl md:text-3xl" style={{ fontWeight: 700 }}>Portal do </span>
            <span className="text-[#FF3333] text-2xl md:text-3xl" style={{ fontWeight: 700 }}>Voto</span>
          </h1>
        </div>

        <div className="p-6 md:p-8 max-w-2xl mx-auto min-h-[calc(100vh-80px)] flex flex-col">
          <h2 className="text-black mb-2 text-center" style={{ fontSize: '30px', fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}>
            {eleicao.nome}
          </h2>
          <p className="text-gray-600 text-center mb-6 text-lg" style={{ fontWeight: 600 }}>
            Total de votos: {totalVotos}
          </p>

          <div className="flex-1 overflow-y-auto mb-6">
            {results.length === 0 ? (
              <div className="flex items-center justify-center min-h-[40vh]">
                <p className="text-gray-500 text-xl text-center" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 900 }}>
                  Nenhum voto registrado ainda
                </p>
              </div>
            ) : (
              <div className="space-y-6">
                {results.map((result, index) => (
                  <div key={result.id} className="bg-white rounded-lg p-6 shadow-md border-l-4 border-[#1976D2]">
                    <h3 className="text-black text-xl mb-4" style={{ fontWeight: 700, fontFamily: 'Poppins, sans-serif' }}>
                      {result.nomeChapa}
                    </h3>

                    <div className="flex items-center gap-6 mb-4">
                      <div className="bg-gray-100 rounded-lg p-4 flex flex-col items-center justify-center">
                        {result.imagemUrl ? (
                          <img src={result.imagemUrl} alt={result.nomeCandidato} className="w-16 h-16 object-cover rounded mb-2" />
                        ) : (
                          <User className="w-16 h-16 text-gray-400 mb-2" />
                        )}
                        <p className="text-black text-center text-sm" style={{ fontWeight: 600 }}>Presidente</p>
                        <p className="text-black text-center text-sm">{result.nomeCandidato}</p>
                      </div>

                      <div className="bg-gray-100 rounded-lg p-4 flex flex-col items-center justify-center">
                        <User className="w-16 h-16 text-gray-400 mb-2" />
                        <p className="text-black text-center text-sm" style={{ fontWeight: 600 }}>Vice</p>
                        <p className="text-black text-center text-sm">{result.nomeVice}</p>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-gray-700" style={{ fontWeight: 600 }}>Número:</span>
                        <span className="text-black text-xl" style={{ fontWeight: 700 }}>{result.numero}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-700" style={{ fontWeight: 600 }}>Votos:</span>
                        <span className="text-black text-xl" style={{ fontWeight: 700 }}>{result.votes}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-700" style={{ fontWeight: 600 }}>Porcentagem:</span>
                        <span className="text-[#1976D2] text-2xl" style={{ fontWeight: 700 }}>{result.percentage}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-6 overflow-hidden mt-2">
                        <div
                          className={`h-full rounded-full transition-all duration-500 ${
                            index === 0 ? 'bg-[#2ECC71]' : 'bg-[#1976D2]'
                          }`}
                          style={{ width: `${result.percentage}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <p className="text-center text-black mb-4 text-lg" style={{ fontWeight: 700 }}>
            {endMessage}
          </p>

          <div className="pt-2">
            <button
              onClick={onBack}
              className="w-full text-black py-4 rounded-lg hover:bg-gray-200 transition-colors text-xl"
              style={{ fontWeight: 700, fontFamily: 'Poppins, sans-serif' }}
            >
              Voltar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}