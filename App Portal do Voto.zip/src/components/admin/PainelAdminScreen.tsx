import { Chapa, Eleicao, Vote as VoteType } from '../../App';

interface PainelAdminScreenProps {
  onBack: () => void;
  chapas: Chapa[];
  eleicoes: Eleicao[];
  votes: VoteType[];
}

export function PainelAdminScreen({ onBack, chapas, eleicoes, votes }: PainelAdminScreenProps) {
  const eleicoesAtivas = eleicoes.filter(e => e.status === 'ativo').length;
  const totalVotos = votes.length;
  
  const voteCounts: { [key: string]: number } = {};
  votes.forEach(vote => {
    voteCounts[vote.chapaNumero] = (voteCounts[vote.chapaNumero] || 0) + 1;
  });

  const resultsWithChapa = chapas.map(chapa => ({
    ...chapa,
    votes: voteCounts[chapa.numero] || 0,
    percentage: totalVotos > 0 
      ? Math.round(((voteCounts[chapa.numero] || 0) / totalVotos) * 100)
      : 0
  })).sort((a, b) => b.votes - a.votes);

  return (
    <div className="min-h-screen bg-[#002169] p-[10px]">
      <div className="min-h-screen bg-[#F6F6F6] rounded-[10px] overflow-hidden">
        <div className="bg-[#002B5C] p-6 flex items-center justify-center">
          <h1 style={{ fontFamily: 'Poppins, sans-serif' }}>
            <span className="text-white text-2xl md:text-3xl" style={{ fontWeight: 700 }}>Portal do </span>
            <span className="text-[#FF3333] text-2xl md:text-3xl" style={{ fontWeight: 700 }}>Voto</span>
          </h1>
        </div>

        <div className="p-6 md:p-8 max-w-2xl mx-auto min-h-[calc(100vh-80px)] flex flex-col">
          <h2 className="text-black mb-6 text-center" style={{ fontSize: '30px', fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}>
            Painel administrativo
          </h2>

          <div className="flex-1">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
              <div className="bg-[#FFC107] rounded-lg p-6">
                <p className="text-black text-3xl mb-1" style={{ fontWeight: 700 }}>{chapas.length}</p>
                <p className="text-black text-sm">Chapas cadastradas</p>
              </div>

              <div className="bg-[#4CAF50] rounded-lg p-6">
                <p className="text-black text-3xl mb-1" style={{ fontWeight: 700 }}>{eleicoes.length}</p>
                <p className="text-black text-sm">Total de eleições</p>
              </div>

              <div className="bg-[#1976D2] rounded-lg p-6">
                <p className="text-black text-3xl mb-1" style={{ fontWeight: 700 }}>{eleicoesAtivas}</p>
                <p className="text-black text-sm">Eleições ativas</p>
              </div>

              <div className="bg-[#9C27B0] rounded-lg p-6">
                <p className="text-black text-3xl mb-1" style={{ fontWeight: 700 }}>{totalVotos}</p>
                <p className="text-black text-sm">Total de votos</p>
              </div>
            </div>
          </div>

          <button
            onClick={onBack}
            className="w-full text-black py-4 rounded-lg hover:bg-gray-200 transition-colors text-lg"
            style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}
          >
            Voltar
          </button>
        </div>
      </div>
    </div>
  );
}