import { ArrowLeft, User } from 'lucide-react';
import { Chapa } from '../../App';

interface CadastrarChapaScreenProps {
  onBack: () => void;
  onCadastrar: () => void;
  onEdit: (chapa: Chapa) => void;
  chapas: Chapa[];
}

export function CadastrarChapaScreen({ onBack, onCadastrar, onEdit, chapas }: CadastrarChapaScreenProps) {
  return (
    <div className="min-h-screen bg-[#002169] p-[10px]">
      <div className="min-h-screen bg-[#F6F6F6] rounded-[10px] overflow-hidden">
        <div className="bg-[#002B5C] p-6 flex items-center justify-center">
          <h1 style={{ fontFamily: 'Poppins, sans-serif' }}>
            <span className="text-white text-2xl md:text-3xl" style={{ fontWeight: 700 }}>Portal do </span>
            <span className="text-[#FF3333] text-2xl md:text-3xl" style={{ fontWeight: 700 }}>Voto</span>
          </h1>
        </div>

        <div className="p-6 md:p-8 max-w-2xl mx-auto min-h-[calc(100vh-80px)] flex flex-col">
          <h2 className="text-black mb-6 text-center" style={{ fontSize: '30px', fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}>
            Cadastro de chapas
          </h2>

          <div className="flex-1">
            {chapas.length === 0 ? (
              <div className="flex items-center justify-center min-h-[40vh]">
                <p className="text-gray-500 text-xl" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 900 }}>Nada criado ainda</p>
              </div>
            ) : (
              <div className="space-y-4 mb-6">
                {chapas.map((chapa) => (
                  <button
                    key={chapa.id}
                    onClick={() => onEdit(chapa)}
                    className="w-full bg-[#80A4F0] rounded-[20px] p-6 hover:bg-[#6F93DF] transition-colors text-left"
                  >
                    <div className="flex items-center justify-between gap-6">
                      <div className="flex-1 space-y-1">
                        {chapa.nomeEleicao && (
                          <p className="text-black mb-2" style={{ fontWeight: 400 }}>
                            <span style={{ fontWeight: 700 }}>Eleição:</span> {chapa.nomeEleicao}
                          </p>
                        )}
                        <p className="text-black" style={{ fontWeight: 400 }}>
                          <span style={{ fontWeight: 700 }}>Chapa:</span> {chapa.nomeChapa}
                        </p>
                        <p className="text-black" style={{ fontWeight: 400 }}>
                          <span style={{ fontWeight: 700 }}>Candidato:</span> {chapa.nomeCandidato}
                        </p>
                        <p className="text-black" style={{ fontWeight: 400 }}>
                          <span style={{ fontWeight: 700 }}>Número de voto:</span> {chapa.numero}
                        </p>
                      </div>

                      <div className="flex items-center justify-center">
                        {chapa.imagemUrl ? (
                          <img src={chapa.imagemUrl} alt={chapa.nomeCandidato} className="w-24 h-24 object-cover rounded-lg" />
                        ) : (
                          <div className="w-24 h-24 bg-white/30 rounded-lg flex items-center justify-center">
                            <User className="w-16 h-16 text-gray-600" />
                          </div>
                        )}
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="space-y-3">
            <button
              onClick={onCadastrar}
              className="w-full bg-[#FFC107] text-white py-4 rounded-lg hover:bg-[#FFB300] transition-colors text-xl"
              style={{ fontWeight: 700, fontFamily: 'Poppins, sans-serif' }}
            >
              Cadastrar
            </button>

            <button
              onClick={onBack}
              className="w-full text-black py-4 rounded-lg hover:bg-gray-200 transition-colors text-xl"
              style={{ fontWeight: 700, fontFamily: 'Poppins, sans-serif' }}
            >
              Voltar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}