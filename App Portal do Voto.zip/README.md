
  # App Portal do Voto

  This is a code bundle for App Portal do Voto. The original project is available at https://www.figma.com/design/AOUgOcX1nwz690P0h6uS8z/App-Portal-do-Voto.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  